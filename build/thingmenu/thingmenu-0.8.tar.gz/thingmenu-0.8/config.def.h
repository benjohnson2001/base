static const Bool wmborder = True;
static const char *font = "-*-*-medium-*-*-*-14-*-*-*-*-*-*-*";
static const char *normbgcolor = "#222222";
static const char *normfgcolor = "#cccccc";
static const char *pressbgcolor = "#ffffff";
static const char *pressfgcolor = "#000000";
static const char *highlightbgcolor = "#bbbbbb";
static const char *highlightfgcolor = "#000000";

static float widthscaling = 1.5;
static float heightscaling = 2.0;

