#ifndef SP_EXPORT_H
#define SP_EXPORT_H

/*
 * text-edit
 *
 * Text editing and font changes
 *
 */

void sp_export_dialog (void);

#endif
