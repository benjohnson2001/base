#ifndef __TOOL_OPTIONS_H__
#define __TOOL_OPTIONS_H__

/*
 * Event context configuration
 *
 * Authors:
 *   Lauris Kaplinski <lauris@kaplinski.com>
 *
 * Copyright (C) 2002 Lauris Kaplinski
 *
 * Released under GNU GPL, read the file 'COPYING' for more information
 */

void sp_tool_options_dialog (void);

#endif
