#ifndef SP_DOCUMENT_PROPERTIES_H
#define SP_DOCUMENT_PROPERTIES_H

#include <gtk/gtk.h>

void sp_document_dialog (void);
void sp_document_dialog_apply (GtkWidget * widget);
void sp_document_dialog_close (GtkWidget * widget);

#endif
