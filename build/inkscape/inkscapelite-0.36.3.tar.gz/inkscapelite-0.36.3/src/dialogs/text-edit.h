#ifndef SP_TEXT_EDIT_H
#define SP_TEXT_EDIT_H

/*
 * text-edit
 *
 * Text editing and font changes
 *
 */

void sp_text_edit_dialog (void);

#endif
