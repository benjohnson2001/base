#ifndef __TOOL_ATTRIBUTES_H__
#define __TOOL_ATTRIBUTES_H__

/*
 * Untyped event context configuration
 *
 * Authors:
 *   Lauris Kaplinski <lauris@kaplinski.com>
 *
 * Copyright (C) 2002 Lauris Kaplinski
 *
 * Released under GNU GPL, read the file 'COPYING' for more information
 */

void sp_tool_attributes_dialog (void);

#endif
