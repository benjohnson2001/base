#ifndef __SP_QUICK_ALIGN_H__
#define __SP_QUICK_ALIGN_H__

/*
 * Object align dialog
 *
 * Authors:
 *   Frank Felfe <innerspace@iname.com>
 *   Lauris Kaplinski <lauris@kaplinski.com>
 *
 * Copyright (C) 1999-2002 Authors
 *
 * Released under GNU GPL, read the file 'COPYING' for more information
 */

void sp_quick_align_dialog (void);

#endif
